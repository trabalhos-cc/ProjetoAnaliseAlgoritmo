package Grafos;

public class Vertice {
	
	private String rotulo;

	public Vertice() {}
	
	public Vertice (String rotulo){
		this.rotulo = rotulo;

	}

	public String getRotulo() {
		return rotulo;
	}

	public void setRotulo(String rotulo) {
		this.rotulo = rotulo;
	}
}
